
package model;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public class LibroDeViajes<T extends CSVSerializable & Comparable<T> & Serializable> {
    
    private List<T> viajes = new ArrayList<>();
    public void agregar(T viaje) {
        viajes.add(viaje);
    }

    public T obtener(int indice) {
        return viajes.get(indice);
    }
    public void eliminar(int indice) {
        viajes.remove(indice);
    }
    
    public void paraCadaElemento(Consumer<T> accion) {
        for (T viaje : viajes) {
            accion.accept(viaje);
        }
    }
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T viaje : viajes) {
            if (criterio.test(viaje)) {
                resultado.add(viaje);
            }
        }
        return resultado;
    }
    public void ordenar() {
        Collections.sort(viajes);
    }

    public void ordenar(Comparator<T> criterio) {
        viajes.sort(criterio);
    }
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(this.viajes);
            System.out.println("Objetos serializados en: " + ruta);
        }
    }
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(ruta))) {
            this.viajes = (List<T>) deserializador.readObject();
            System.out.println("Objetos deserializados correctamente.");
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for (T viaje : viajes) {
                escritor.write(viaje.toCSV());
                escritor.newLine();
            }
            System.out.println("Archivo CSV guardado en: " + ruta);
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> conversor) throws IOException {
        this.viajes.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    T objeto = conversor.apply(linea);
                    this.viajes.add(objeto);
                }
            }
            System.out.println("Archivo CSV cargado.");
        }
    }

}
