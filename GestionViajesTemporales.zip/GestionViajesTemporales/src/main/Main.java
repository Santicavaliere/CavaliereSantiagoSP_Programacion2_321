
package main;

import config.RutasArchivos;
import java.io.IOException;
import model.DestinoTemporal;
import model.LibroDeViajes;
import model.ViajeTemporal;

public class Main {
    public static void main(String[] args) {
        
        try {
            LibroDeViajes<ViajeTemporal> libro = new LibroDeViajes<>();
            
            libro.agregar(new ViajeTemporal(1, "Salvar a George McFly", "Marty McFly", DestinoTemporal.HILL_VALLEY_1955));
            libro.agregar(new ViajeTemporal(2, "Buscar el Almanaque Deportivo", "Marty McFly", DestinoTemporal.HILL_VALLEY_2015));
            libro.agregar(new ViajeTemporal(3, "Impedir la realidad alternativa de Biff", "Doc Brown", DestinoTemporal.REALIDAD_ALTERNATIVA));
            libro.agregar(new ViajeTemporal(4, "Rescatar a Clara en el puente", "Doc Brown", DestinoTemporal.FAR_WEST_1885));
            libro.agregar(new ViajeTemporal(5, "Restaurar la linea temporal original", "Marty McFly", DestinoTemporal.LINEA_RESTAURADA));

            System.out.println("Viajes en el tiempo:");
            libro.paraCadaElemento(v -> System.out.println(v));

            System.out.println("\nViajes a 1955:");
            libro.filtrar(v -> v.getDestino() == DestinoTemporal.HILL_VALLEY_1955)
                 .forEach(System.out::println);

            System.out.println("\nViajes que contienen 'almanaque':");
            libro.filtrar(v -> v.getDescripcion().toLowerCase().contains("almanaque"))
                 .forEach(System.out::println);

            System.out.println("\nViajes ordenados por ID:");
            libro.ordenar(); 
            libro.paraCadaElemento(System.out::println);

            System.out.println("\nViajes ordenados por descripción:");
            libro.ordenar((v1, v2) -> v1.getDescripcion().compareTo(v2.getDescripcion()));
            libro.paraCadaElemento(System.out::println);

            libro.guardarEnArchivo(RutasArchivos.getRutaBIN());

            LibroDeViajes<ViajeTemporal> libroCargado = new LibroDeViajes<>();
            libroCargado.cargarDesdeArchivo(RutasArchivos.getRutaBIN());
            
            System.out.println("\nViajes cargados desde archivo binario:");
            libroCargado.paraCadaElemento(System.out::println);

            libro.guardarEnCSV(RutasArchivos.getRutaCSV());
            
            libroCargado.cargarDesdeCSV(RutasArchivos.getRutaCSV(), linea -> ViajeTemporal.fromCSV(linea));
            
            System.out.println("\nViajes cargados desde archivo CSV:");
            libroCargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}