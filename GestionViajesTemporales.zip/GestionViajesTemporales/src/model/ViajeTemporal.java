
package model;

import java.io.Serializable;
import java.util.Objects;

public class ViajeTemporal implements Comparable<ViajeTemporal>, CSVSerializable, Serializable {
    private static final long serialVersionUID = 1L;
    
    private int id;
    private String descripcion;
    private String viajero;
    private DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }
    public String getDescripcion(){ 
        return descripcion; 
    }
    public String getViajero(){ 
        return viajero; 
    }
    public DestinoTemporal getDestino(){ 
        return destino; 
    }
    public int getId(){ 
        return id; 
    }

    @Override
    public String toString() {
        return "Viaje {" + "id=" + id + ", desc='" + descripcion + '\'' + ", viajero='" + viajero + '\'' + ", destino=" + destino + '}';
    }

    @Override
    public int compareTo(ViajeTemporal o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + descripcion + "," + viajero + "," + destino;
    }
    public static ViajeTemporal fromCSV(String linea) {
        String[] datos = linea.split(",");
        int id = Integer.parseInt(datos[0]);
        String descripcion = datos[1];
        String viajero = datos[2];
        DestinoTemporal destino = DestinoTemporal.valueOf(datos[3]);
        return new ViajeTemporal(id, descripcion, viajero, destino);
    }
}