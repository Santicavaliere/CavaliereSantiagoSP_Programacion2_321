
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivos {
    static final String BASE = "src/data/"; // El PDF usa la carpeta data
    static final String FILE_BIN = "viajes.dat";
    static final String FILE_CSV = "viajes.csv";

    static String getRutaBIN() {
        return Paths.get(BASE, FILE_BIN).toString();
    }

    static String getRutaCSV() {
        return Paths.get(BASE, FILE_CSV).toString();
    }
}